<?php
/********************************************
 FRAME WORK CODE STARTS HERE
*********************************************/
/********************************************
 THEME VARIABLES
*********************************************/
global $incart_lite_themename;
global $incart_lite_shortname;
require_once(get_template_directory().'/SketchBoard/functions/sketch-functions.php');                // Pagination, excerpt control etc.
require_once(get_template_directory().'/SketchBoard/functions/sketch-enqueue.php');                  // Enqueue Css Scripts
require_once(get_template_directory().'/SketchBoard/functions/sketch-breadcrumb.php');               // Include Breadcrumb       // Includes Widget