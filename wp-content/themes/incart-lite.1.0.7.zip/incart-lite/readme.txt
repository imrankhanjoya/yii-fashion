== Copyright and License ==

Incart WordPress Theme, Copyright 2014 SketchThemes.
Incart WordPress theme is distributed under the terms of the GNU GPL.


/*========= Credits =========*/

Theme Incart uses js :-
* The script cbpAnimatedHeader.js v1.0.0 is licensed under the MIT license.
* The script jquery.easing.1.3.js v1.3.0 is licensed under the BSD License.
* The script hoverIntent.js is licensed under the MIT License.
* The script jquery.prettyPhoto.js v3.1.4 is licensed under the "GPLv2 license".
* The script superfish.js v1.7.4 is licensed under the MIT and GPL.
* The script waypoints.js is licensed under the MIT.

Theme Incart uses CSS :-
* The CSS bootstrap-responsive.css is licensed under the Apache License v2.0.
* The CSS font-awesome.css is licensed under the MIT License.
* The CSS prettyPhoto.css is licensed under the "GPLv2 license".
* The CSS superfish.css is licensed under  MIT and GPL.

Theme Incart uses Font :-
* Icon Set: FontAwesome and Elusive Iconfont is licensed under MIT License �
* Google Webfonts: Roboto Condensed is licensed under Apache License, version 2.0.
* Google Webfonts: Lato is licensed under SIL Open Font License, 1.1.

Option Tree Credits :-
* Option Tree Framework is licensed under GPLv3�(https://github.com/valendesigns/option-tree-theme)

* The uses images is licensed under Creative Commons CC0:
	http://pixabay.com/en/asian-woman-asia-sunset-sunlight-413123/
	http://pixabay.com/en/fashion-blue-silhouettes-actress-279620/
	http://pixabay.com/en/girl-sunset-summer-beach-woman-437989/
	http://pixabay.com/en/asian-woman-asia-sunset-sunlight-413122/

* All other images('cart.png', 'ch-arr.png', 'corner-arrow.png', 'menuulbg.png') were created by SketchThemes and are licensed under "CC0-License".


== Changelog ==

= 1.0.6 =
* WP 4.6 compatible

= 1.0.5 =
* Removed composer file.
* Fixed untranslatable text.

= 1.0.4 =
* Added .pot file.

= 1.0.3 =
* Added escaped values.
* Added .po file.
* Added sketchthemes image License.

= 1.0.2 =
* Remove unnecessary files.

= 1.0.1 =
* Fixed responsive issue.
* Fixed images alignment issue.

= 1.0.0 =
* Initial release
