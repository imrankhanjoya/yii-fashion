<div class="Skt-header-image">
	<!-- header image -->
		<div class="incart-image-post"><img alt="<?php _e('incart-default-slider-image','incart-lite');?>" class="ad-slider-image" width="1585"  src="<?php if(sketch_get_option($incart_lite_shortname.'_frontslider_stype')) { echo sketch_get_option($incart_lite_shortname.'_frontslider_stype'); } else { echo get_template_directory_uri().'/images/Slider-Image01.png'; } ?>" ></div>
	<!-- end  header image  -->
</div>