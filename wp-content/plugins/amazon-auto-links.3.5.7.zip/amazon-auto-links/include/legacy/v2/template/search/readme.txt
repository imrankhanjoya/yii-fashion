== Change log ==

= 1.0.4 =
- Added a style for discounted price element.

= 1.0.3 =
- Chagned some local variable names.

= 1.0.2 =
- Tweaked the styling to horizontally center the Not Found image.

= 1.0.1 - 03/07/2014 =
- Added the class selectors representing unit ID and the label to the products container element.

= 1.0.0 =
Initial release.