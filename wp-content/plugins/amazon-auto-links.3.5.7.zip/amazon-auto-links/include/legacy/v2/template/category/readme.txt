== Change log ==

= 1.0.3 =
- Changed local variable names.

= 1.0.2 - 05/27/2014 =
- Tweaked the styling to center the not found image.

= 1.0.1 - 03/07/2014 =
- Added the class selectors representing unit ID and the label to the products container element.

= 1.0.0 =
Initial release.