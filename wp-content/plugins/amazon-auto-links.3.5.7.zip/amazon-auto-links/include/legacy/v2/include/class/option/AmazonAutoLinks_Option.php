<?php
/**
 * Handles the options of Amazon Auto Links.
 * 
 * @package     Amazon Auto Links
 * @copyright   Copyright (c) 2013, Michael Uno
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since        2.0.0
 * 
 */
class AmazonAutoLinks_Option extends AmazonAutoLinks_Option_ {}