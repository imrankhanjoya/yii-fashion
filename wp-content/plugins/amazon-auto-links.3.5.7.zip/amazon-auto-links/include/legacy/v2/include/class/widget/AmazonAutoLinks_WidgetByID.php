<?php
class AmazonAutoLinks_WidgetByID extends AmazonAutoLinks_WidgetByID_ {}