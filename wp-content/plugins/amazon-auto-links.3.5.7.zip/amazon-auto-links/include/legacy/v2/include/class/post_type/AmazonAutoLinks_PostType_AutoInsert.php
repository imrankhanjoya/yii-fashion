<?php 
class AmazonAutoLinks_PostType_AutoInsert extends AmazonAutoLinks_PostType_AutoInsert_ {}