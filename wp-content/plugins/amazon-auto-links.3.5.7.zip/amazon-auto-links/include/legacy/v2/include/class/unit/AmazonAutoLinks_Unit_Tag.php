<?php
class AmazonAutoLinks_Unit_Tag extends AmazonAutoLinks_Unit_Tag_ {}