<?php
/**
 * Performs requests to the Product Advertising API.
 * 
 * @package         Amazon Auto Links
 * @copyright       Copyright (c) 2013, Michael Uno
 * @license         http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

class AmazonAutoLinks_ProductAdvertisingAPI extends AmazonAutoLinks_ProductAdvertisingAPI_ {}