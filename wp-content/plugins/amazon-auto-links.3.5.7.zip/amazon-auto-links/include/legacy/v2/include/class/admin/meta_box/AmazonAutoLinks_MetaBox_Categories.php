<?php
class AmazonAutoLinks_MetaBox_Categories extends AmazonAutoLinks_MetaBox_Categories_ {}