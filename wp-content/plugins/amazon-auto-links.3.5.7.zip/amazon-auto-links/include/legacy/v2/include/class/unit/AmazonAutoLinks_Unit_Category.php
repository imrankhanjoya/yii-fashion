<?php
class AmazonAutoLinks_Unit_Category extends  AmazonAutoLinks_Unit_Category_{}