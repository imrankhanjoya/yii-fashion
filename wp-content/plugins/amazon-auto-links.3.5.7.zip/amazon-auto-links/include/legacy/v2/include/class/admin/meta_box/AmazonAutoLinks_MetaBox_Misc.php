<?php
class AmazonAutoLinks_MetaBox_Misc extends AmazonAutoLinks_MetaBox_Misc_ {}