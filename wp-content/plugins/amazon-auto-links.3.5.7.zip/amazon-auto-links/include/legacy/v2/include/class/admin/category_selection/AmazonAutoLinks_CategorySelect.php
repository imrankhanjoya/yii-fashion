<?php
class AmazonAutoLinks_CategorySelect extends AmazonAutoLinks_CategorySelect_ {}