<?php
/**
    Event handler.
    
 * @package     Amazon Auto Links
 * @copyright   Copyright (c) 2013, Michael Uno
 * @authorurl    http://michaeluno.jp
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since        2.0.0
 * 
    
*/
final class AmazonAutoLinks_Event extends AmazonAutoLinks_Event_ {}