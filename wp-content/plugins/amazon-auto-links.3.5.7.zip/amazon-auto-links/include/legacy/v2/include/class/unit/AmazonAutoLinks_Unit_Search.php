<?php
class AmazonAutoLinks_Unit_Search extends AmazonAutoLinks_Unit_Search_ {}