<?php
class AmazonAutoLinks_Form_Search extends AmazonAutoLinks_Form_Search_{}